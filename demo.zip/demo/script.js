// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    },
    {
      "type": "lab.plugins.Download",
      "filePrefix": "study",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 425.41,
          "height": 48.82,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "This experiment requires full screen display.\nPlease press the SPACE bar to enter fullscreen ",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "20",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {},
      "parameters": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
this.options.events['keypress(Space)'] = function() {
 lab.util.fullscreen.launch(document.documentElement)
  this.end()
}
}
      },
      "title": "enter_fullscreen"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "buffer",
      "timeout": "2000"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 391.3,
          "height": 120.05,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "welcome to the experiment!\n\npress ENTER to start",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Enter)": "enter_exp"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "welcome"
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": -50,
          "angle": 0,
          "width": 760.36,
          "height": 248.78,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "Thank you for participating in our experiment! The task will take you approximately \n30-45 minutes. First you will read the informed consent document and, if you agree, consent to \nparticipate. Then you will start the three-phase experiment. Each phase will begin with instructions. \nThe first phase will take approximately 6 minutes. You will then complete a visual-search \ntask for 2 minutes (there will be instructions).\n\nThe second phase will be a new task with new instructions. This phase will take approximately 5 minutes, \nfollowed by the same 2-minute visual search task as before. Finally, the third phase is a different task and \nwill begin with new instructions. The third phase will take approximately 7-8 minutes.\n\nPlease pay careful attention to the instructions and focus on the experiment. Your participation is \nmeaningful to the scientific community. We appreciate your time!",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "16",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        },
        {
          "type": "i-text",
          "left": 11,
          "top": 175,
          "angle": 0,
          "width": 225.65,
          "height": 22.6,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "press ENTER to continue",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": "20",
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {
        "keypress(Enter)": "enter_overview"
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "overview"
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cmain\u003E\n\u003C!-- Consent statement: --\u003E\n  \u003Cdiv id=\"consentDiv\"\u003E\u003Ccenter\u003E\u003Ch1\u003EVanderbilt University Consent to Participate in Research\u003C\u002Fh1\u003E\u003Cp\u003E\u003Cb\u003EThis is a consent form for research participation.\u003C\u002Fb\u003E It contains important information about this study and what to expect if you decide to participate.\u003C\u002Fp\u003E\n    \u003Ciframe src=\"https:\u002F\u002Fmturk-s3-categories.s3.amazonaws.com\u002FStamped-ICD.pdf\" width=\"100%\" height=\"500px\"\u003E\u003C\u002Fiframe\u003E\n    \u003Cp\u003E\u003Cb\u003EElectronic consent:\u003C\u002Fb\u003E You may print a copy of this consent form for your records. \u003Cbr\u003E\u003Cbr\u003E You must be 18 years of age or older to participate in this experiment. Please enter your age in the box below. \u003Cbr\u003EClicking the start button below indicates that you have read the above information and you voluntarily agree to participate in the experiment.\u003C\u002Fcenter\u003E \n  \u003C\u002Fcenter\u003E\u003C\u002Fdiv\u003E\n    \u003Cform\u003E\n    \u003Cbr\u003E \n    \u003Clabel for =\"age\"\u003E Age of participant: \u003C\u002Flabel\u003E\n    \u003Cinput type=\"number\" name=\"age\" id=\"age\" required autocomplete=\"off\"\u003E \u003Cbr\u003E\u003Cbr\u003E\n    \u003Cinput type=\"checkbox\" name=\"consent\" id=\"consent\" required\u003E\n    \u003Clabel for =\"consent\"\u003E I consent to this experiment \u003C\u002Flabel\u003E\u003Cbr\u003E \n    \u003Cbutton type=\"submit\"\u003E\n      Start\n    \u003C\u002Fbutton\u003E\n  \u003C\u002Fform\u003E\n\u003C\u002Fmain\u003E",
      "scrollTop": true,
      "files": {},
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "consent_form"
    },
    {
      "type": "lab.html.Form",
      "content": "\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\n  \u003Cdiv class=\"w-l text-left\" style=\"display: block\"\u003E\n    \n    \u003Ch2 class=\"text-center\"\u003EPlease tell us about yourself\u003C\u002Fh2\u003E\n    \u003Cp class=\"text-center\"\u003E\u003C\u002Fp\u003E\n    \n    \u003Cform id=\"demography\"\u003E\n      \u003Ctable\u003E\n        \u003C!-- Age --\u003E\n        \u003Ctr style=\"height: 50px\"\u003E\n          \u003Ctd class=\"font-weight-bold\"\u003E\n            What is your current gender identity?\n          \u003C\u002Ftd\u003E\n          \u003Ctd\u003E\n            \u003Cinput name=\"gender\" type=\"letter\" required class=\"w-100\" autocomplete=\"off\"\u003E\n          \u003C\u002Ftd\u003E\n        \u003C\u002Ftr\u003E\n        \n        \u003C!-- Gender identity, following Tate et al. (2013) --\u003E\n        \u003Ctr style=\"height: 100px\"\u003E\n          \u003Ctd class=\"font-weight-bold\"\u003E\n            How do you usually describe your race?\n          \u003C\u002Ftd\u003E\n          \u003Ctd\u003E\n            \u003Cselect name=\"race\" required class=\"w-100\"\u003E\n              \u003Coption value=\"\" selected\u003E\n                -- Please click to select --\n              \u003C\u002Foption\u003E\n              \n              \u003Coption value=\"AmericanIndian\u002FNativeAlaskan\"\u003EAmerican Indian or Native Alaskan\u003C\u002Foption\u003E\n              \u003Coption value=\"Asian\u002FAsianAmerican\"\u003EAsian or Asian American\u003C\u002Foption\u003E\n              \u003Coption value=\"Black\u002FAfricanAmerican\"\u003EBlack or African American\u003C\u002Foption\u003E\n              \u003Coption value=\"Hispanic\u002FLatino\u002Fa\u002Fx\"\u003EHispanic or Latino\u002Fa\u002Fx\u003C\u002Foption\u003E\n              \u003Coption value=\"MiddleEastern\u002FNorth African\"\u003EMiddle Eastern\u002FNorth African (MENA) or Arab Origin\u003C\u002Foption\u003E\n              \u003Coption value=\"NativeHawaiian\u002FOtherPacificIslander\"\u003ENative Hawaiian or Other Pacific Islander Native\u003C\u002Foption\u003E\n              \u003Coption value=\"White\"\u003EWhite\u003C\u002Foption\u003E\n              \u003Coption value=\"Biracial or Multiracial\"\u003EBiracial or Multiracial\u003C\u002Foption\u003E\n              \u003Coption value=\"Other\"\u003EMy identity is not listed above\u003C\u002Foption\u003E\n              \n            \u003C\u002Fselect\u003E\n          \u003C\u002Ftd\u003E\n        \u003C\u002Ftr\u003E\n        \n        \u003C!-- Birth-assigned gender category, following Tate et al.\n          \u003Ctr style=\"height: 100px\"\u003E\n            \u003Ctd\u003E\n              Which gender were you assigned at birth?\n            \u003C\u002Ftd\u003E\n            \u003Ctd\u003E\n              \u003Cselect style=\"width: 200px\" name=\"gender-birth\"\u003E\n                \u003Coption value=\"\" selected\u003E\n                  -- Please click to select --\n                \u003C\u002Foption\u003E\n                \u003Coption value=\"female\"\u003EFemale\u003C\u002Foption\u003E\n                \u003Coption value=\"male\"\u003EMale\u003C\u002Foption\u003E\n                \u003Coption value=\"intersex\"\u003EIntersex\u003C\u002Foption\u003E\n              \u003C\u002Fselect\u003E\n            \u003C\u002Ftd\u003E\n          \u003C\u002Ftr\u003E\n        --\u003E\n\n        \u003C!-- Education\n        \u003Ctr style=\"height: 100px\"\u003E\n          \u003Ctd\u003E\n            Please specify your highest degree:\n          \u003C\u002Ftd\u003E\n          \u003Ctd\u003E\n            \u003Cselect name=\"education\" class=\"w-100\"\u003E\n              \u003Coption value=\"\" selected\u003E\n                -- Please click to select --\n              \u003C\u002Foption\u003E\n              \u003Coption value=\"no\"\u003Eno degree\u003C\u002Foption\u003E\n              \u003Coption value=\"highschool\"\u003EHigh school diploma\u003C\u002Foption\u003E\n              \u003Coption value=\"bachelor\"\u003EBachelor's\u003C\u002Foption\u003E\n              \u003Coption value=\"master\"\u003EMaster's\u003C\u002Foption\u003E\n              \u003Coption value=\"phd\"\u003EPhD\u003C\u002Foption\u003E\n            \u003C\u002Fselect\u003E\n          \u003C\u002Ftd\u003E\n        \u003C\u002Ftr\u003E\n        --\u003E\n\n        \u003C!-- Occupation\n        \u003Ctr style=\"height: 100px\"\u003E\n          \u003Ctd\u003E\n            What is your occupation, or if you still study, your field?\n          \u003C\u002Ftd\u003E\n          \u003Ctd\u003E\n            \u003Cinput name=\"occupation\" class=\"w-100\"\u003E\n          \u003C\u002Ftd\u003E\n        \u003C\u002Ftr\u003E\n        --\u003E\n\n        \u003C!-- Column balance --\u003E\n        \u003Ccolgroup\u003E\n          \u003Ccol style=\"width: 45%\"\u003E\n          \u003Ccol style=\"width: 65%\"\u003E\n        \u003C\u002Fcolgroup\u003E\n      \u003C\u002Ftable\u003E\n    \u003C\u002Fform\u003E\n  \u003C\u002Fdiv\u003E\n\u003C\u002Fmain\u003E\n\n\u003Cfooter class=\"content-vertical-center content-horizontal-right\"\u003E\n  \u003Cbutton type=\"submit\" form=\"demography\"\u003EContinue &rarr;\u003C\u002Fbutton\u003E\n\u003C\u002Ffooter\u003E",
      "parameters": {},
      "responses": {},
      "messageHandlers": {},
      "title": "demographics_form",
      "files": {}
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "parameters": {},
      "responses": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
let done = false // is it the last screen?

const setVisibility = (selector, isVisible) => {
  // Extract the content from the current element
  const target = this.options.el.querySelector(selector)

  target.style.visibility = isVisible ? 'visible' : 'hidden'
}

const moveForth = (selector) => {
  const target = this.options.el.querySelector(selector)
  if(target.nextElementSibling){
    target.classList.add("hidden"); // hide current screen
    target.nextElementSibling.classList.remove("hidden"); //show next screen

    setVisibility('#bck', true) // make sure that 'back' button is visible

    if(!target.nextElementSibling.nextElementSibling){ // if the end is reached
      setVisibility('#fwd', false) // hide the forward button
      setVisibility('#done', true) // show the end button
      done = true
    }
  }
}

const moveBack = (selector) => {
  target = this.options.el.querySelector(selector);
  if(target.previousElementSibling){ //.innerHTML !== undefined
    target.classList.add("hidden");  // hide current screen
    target.previousElementSibling.classList.remove("hidden"); // show previous screen

    setVisibility('#fwd', true) // make sure that 'forward' button is visible
    setVisibility('#done', false) // hide the 'done' button
    done = false

    if(!target.previousElementSibling.previousElementSibling){ // if the beginning is reached
      setVisibility('#bck', false) // hide the back button
    }
  }
}

this.options.events['keydown(ArrowRight)'] = function(){
  moveForth("section[id^='page']:not(.hidden)")
  moveForth("h2[id^='head']:not(.hidden)")
}

this.options.events['keydown(ArrowLeft)'] = function(){
  moveBack("section[id^='page']:not(.hidden)")
  moveBack("h2[id^='head']:not(.hidden)")
}

this.options.events['keypress(Enter)'] = function() {
    if(done)
      // End instructions
      this.end('done')
}
}
      },
      "title": "general_instructions",
      "content": "\u003Cheader\u003E\r\n  \u003Ch2 id=\"head1\"\u003E\u003C\u002Fh2\u003E\r\n  \u003Ch2 id=\"head2\" class=\"hidden\"\u003E\u003C\u002Fh2\u003E\r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\r\n  \u003Csection id=\"page1\"\u003E\r\n    \u003Cfont size=\"6\"\u003EThis is an example of instructions. \u003Cbr\u003E\u003Cbr\u003E \r\nIt allows participants to move back and forth.\u003Cbr\u003E\u003C\u002Ffont\u003E\r\n\u003Cfont size=\"6\"\u003EYou can set which keypresses the code waits for. \u003C\u002Ffont\u003E\r\n    \u003Cp\u003E\r\n\u003C\u002Fp\u003E\r\n  \u003C\u002Fsection\u003E\r\n  \u003Csection id=\"page2\" class=\"w-l hidden\"\u003E\r\n    \u003Cp\u003E\u003Cfont size=\"6\"\u003EYou will see items in the centre of the screen. \u003C\u002Ffont\u003E \u003Cbr\u003E\u003Cfont size=\"2\"\u003EThese items are presented for a certain amount of time \u003C\u002Ffont\u003E \u003Cfont size=\"6\"\u003E \u003Cbr\u003Ethe code will automatically move on.\u003C\u002Ffont\u003E\u003Cbr\u003E\u003Cbr\u003E\u003Cbr\u003EPress ENTER to begin\u003C\u002Fp\u003E\u003C\u002Ffont\u003E\r\n  \u003C\u002Fsection\u003E\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003Cfooter\u003E\r\n  \u003Ctable class=\"table-plain\"\u003E\r\n    \u003Ctr\u003E\r\n      \u003Ctd id=\"bck\" style=\"visibility: hidden\"\u003E\r\n        press the left arrow \u003Ckbd\u003E&larr;\u003C\u002Fkbd\u003E for the previous screen \r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd id=\"done\" style=\"visibility: hidden\"\u003E\r\n        press \u003Ckbd\u003EENTER\u003C\u002Fkbd\u003E to continue \r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd id=\"fwd\"\u003E\r\n        press the right arrow \u003Ckbd\u003E&rarr;\u003C\u002Fkbd\u003E for the next screen \r\n      \u003C\u002Ftd\u003E\r\n    \u003C\u002Ftr\u003E\r\n  \u003C\u002Ftable\u003E\r\n\u003C\u002Ffooter\u003E"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "image1": "mixer1.jpg"
        },
        {
          "image1": "volleyball1.jpg"
        },
        {
          "image1": "wateringcan1.jpg"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {
        "volleyball1.jpg": "embedded\u002F8168d1eab84f03f0213dff9a9a3ec38d3b1335bc59bdff4d3d3f4417af1af8f2.jpg",
        "wateringcan1.jpg": "embedded\u002Fddf2e5110fa872f32081cbf395250eb49347325a01857785216821da69b5cb7f.jpg",
        "mixer1.jpg": "embedded\u002F942666d5b8cfdaace275e88d5a8fff14c907828d69edb66d2b3188591bdbf9f9.jpg"
      },
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "present_timed_image_loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {},
        "parameters": {},
        "messageHandlers": {},
        "title": "present_timed_image_sequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {},
            "parameters": {},
            "messageHandlers": {},
            "title": "ISI",
            "timeout": "400"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "image",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 256,
                "height": 256,
                "stroke": null,
                "strokeWidth": 0,
                "fill": "black",
                "src": "${ this.files[this.parameters.image1] }"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {
              "rockinghorse1.jpg": "embedded\u002F94c39750558981f14fc893caf31be6b5fa2657d343d99e007dd38889943eaf30.jpg"
            },
            "responses": {},
            "parameters": {},
            "messageHandlers": {},
            "title": "present_timed_image_stim",
            "timeout": "3000"
          }
        ]
      }
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "parameters": {},
      "responses": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
let done = false // is it the last screen?

const setVisibility = (selector, isVisible) => {
  // Extract the content from the current element
  const target = this.options.el.querySelector(selector)

  target.style.visibility = isVisible ? 'visible' : 'hidden'
}

const moveForth = (selector) => {
  const target = this.options.el.querySelector(selector)
  if(target.nextElementSibling){
    target.classList.add("hidden"); // hide current screen
    target.nextElementSibling.classList.remove("hidden"); //show next screen

    setVisibility('#bck', true) // make sure that 'back' button is visible

    if(!target.nextElementSibling.nextElementSibling){ // if the end is reached
      setVisibility('#fwd', false) // hide the forward button
      setVisibility('#done', true) // show the end button
      done = true
    }
  }
}

const moveBack = (selector) => {
  target = this.options.el.querySelector(selector);
  if(target.previousElementSibling){ //.innerHTML !== undefined
    target.classList.add("hidden");  // hide current screen
    target.previousElementSibling.classList.remove("hidden"); // show previous screen

    setVisibility('#fwd', true) // make sure that 'forward' button is visible
    setVisibility('#done', false) // hide the 'done' button
    done = false

    if(!target.previousElementSibling.previousElementSibling){ // if the beginning is reached
      setVisibility('#bck', false) // hide the back button
    }
  }
}

this.options.events['keydown(ArrowRight)'] = function(){
  moveForth("section[id^='page']:not(.hidden)")
  moveForth("h2[id^='head']:not(.hidden)")
}

this.options.events['keydown(ArrowLeft)'] = function(){
  moveBack("section[id^='page']:not(.hidden)")
  moveBack("h2[id^='head']:not(.hidden)")
}

this.options.events['keypress(Enter)'] = function() {
    if(done)
      // End instructions
      this.end('done')
}
}
      },
      "title": "general_instructions2",
      "content": "\u003Cheader\u003E\r\n  \u003Ch2 id=\"head1\"\u003E\u003C\u002Fh2\u003E\r\n  \u003Ch2 id=\"head2\" class=\"hidden\"\u003E\u003C\u002Fh2\u003E\r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\r\n  \u003Csection id=\"page1\"\u003E\r\n    \u003Cfont size=\"6\"\u003EMore instructions. \u003Cbr\u003E\u003Cbr\u003E \r\nThe next loop is an example of how to wait for a key response.\u003Cbr\u003E\u003C\u002Ffont\u003E\r\n    \u003Cp\u003E\r\n\u003C\u002Fp\u003E\r\n  \u003C\u002Fsection\u003E\r\n  \u003Csection id=\"page2\" class=\"hidden\"\u003E\r\n    \u003Cp\u003E\u003Cfont size=\"6\"\u003EYou will see items in the centre of the screen. This time the code waits for a key response. \u003Cbr\u003EIn this case it is K or L (all others are not logged). Along with the image filenames, we give the code a 'correct_resp' vector and it compares that to the keypress. \u003Cbr\u003EThe final dataframe has a logical 'correct' vector.\u003Cbr\u003E\u003Cbr\u003EPress ENTER to check it out\u003C\u002Fp\u003E\u003C\u002Ffont\u003E\r\n  \u003C\u002Fsection\u003E\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003Cfooter\u003E\r\n  \u003Ctable class=\"table-plain\"\u003E\r\n    \u003Ctr\u003E\r\n      \u003Ctd id=\"bck\" style=\"visibility: hidden\"\u003E\r\n        press the left arrow \u003Ckbd\u003E&larr;\u003C\u002Fkbd\u003E for the previous screen \r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd id=\"done\" style=\"visibility: hidden\"\u003E\r\n        press \u003Ckbd\u003EENTER\u003C\u002Fkbd\u003E to continue \r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd id=\"fwd\"\u003E\r\n        press the right arrow \u003Ckbd\u003E&rarr;\u003C\u002Fkbd\u003E for the next screen \r\n      \u003C\u002Ftd\u003E\r\n    \u003C\u002Ftr\u003E\r\n  \u003C\u002Ftable\u003E\r\n\u003C\u002Ffooter\u003E"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "image1": "ring2.jpg",
          "correct_resp": "old"
        },
        {
          "image1": "rubberduck1.jpg",
          "correct_resp": "old"
        },
        {
          "image1": "rockinghorse1.jpg",
          "correct_resp": "new"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {
        "ring2.jpg": "embedded\u002F5f5b1a96da52509b3f3c1acaa0f7f44a3decd7cd41c6c4551e6a10e290e58017.jpg",
        "rockinghorse1.jpg": "embedded\u002F94c39750558981f14fc893caf31be6b5fa2657d343d99e007dd38889943eaf30.jpg",
        "rubberduck1.jpg": "embedded\u002Ffbd80973b97e7b8e6f6ca937131578511c75a5172781dc12ed7e27c3368f1056.jpg"
      },
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "present_keypress_image_loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {},
        "parameters": {},
        "messageHandlers": {},
        "title": "present_keypress_image_sequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {},
            "parameters": {},
            "messageHandlers": {},
            "title": "ISI",
            "timeout": "600"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "image",
                "left": 0,
                "top": -40,
                "angle": 0,
                "width": 256,
                "height": 256,
                "stroke": null,
                "strokeWidth": 0,
                "fill": "black",
                "src": "${ this.files[this.parameters.image1] }"
              },
              {
                "type": "i-text",
                "left": 0,
                "top": 175,
                "angle": 0,
                "width": 255.69,
                "height": 22.6,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "press K for old and L for new",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "20",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {
              "backpack1.jpg": "embedded\u002F7283233f216629f56ec26db54701d15738745a97b02b46ba00fe91a91ce8dc42.jpg"
            },
            "responses": {
              "keypress(k)": "old",
              "keypress(l)": "new"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "present_keypress_image_stimuli",
            "correctResponse": "${ [this.parameters.correct_resp] }"
          }
        ]
      }
    },
    {
      "type": "lab.html.Screen",
      "files": {},
      "parameters": {},
      "responses": {},
      "messageHandlers": {
        "before:prepare": function anonymous(
) {
let done = false // is it the last screen?

const setVisibility = (selector, isVisible) => {
  // Extract the content from the current element
  const target = this.options.el.querySelector(selector)

  target.style.visibility = isVisible ? 'visible' : 'hidden'
}

const moveForth = (selector) => {
  const target = this.options.el.querySelector(selector)
  if(target.nextElementSibling){
    target.classList.add("hidden"); // hide current screen
    target.nextElementSibling.classList.remove("hidden"); //show next screen

    setVisibility('#bck', true) // make sure that 'back' button is visible

    if(!target.nextElementSibling.nextElementSibling){ // if the end is reached
      setVisibility('#fwd', false) // hide the forward button
      setVisibility('#done', true) // show the end button
      done = true
    }
  }
}

const moveBack = (selector) => {
  target = this.options.el.querySelector(selector);
  if(target.previousElementSibling){ //.innerHTML !== undefined
    target.classList.add("hidden");  // hide current screen
    target.previousElementSibling.classList.remove("hidden"); // show previous screen

    setVisibility('#fwd', true) // make sure that 'forward' button is visible
    setVisibility('#done', false) // hide the 'done' button
    done = false

    if(!target.previousElementSibling.previousElementSibling){ // if the beginning is reached
      setVisibility('#bck', false) // hide the back button
    }
  }
}

this.options.events['keydown(ArrowRight)'] = function(){
  moveForth("section[id^='page']:not(.hidden)")
  moveForth("h2[id^='head']:not(.hidden)")
}

this.options.events['keydown(ArrowLeft)'] = function(){
  moveBack("section[id^='page']:not(.hidden)")
  moveBack("h2[id^='head']:not(.hidden)")
}

this.options.events['keypress(Enter)'] = function() {
    if(done)
      // End instructions
      this.end('done')
}
}
      },
      "title": "general_instructions3",
      "content": "\u003Cheader\u003E\r\n  \u003Ch2 id=\"head1\"\u003E\u003C\u002Fh2\u003E\r\n  \u003Ch2 id=\"head2\" class=\"hidden\"\u003E\u003C\u002Fh2\u003E\r\n\u003C\u002Fheader\u003E\r\n\r\n\u003Cmain class=\"content-horizontal-center content-vertical-center\"\u003E\r\n  \u003Csection id=\"page1\"\u003E\r\n    \u003Cfont size=\"6\"\u003EMore instructions. \u003Cbr\u003E\u003Cbr\u003E \r\nThe next loop is an example of \u003Cbr\u003E1. presenting more than image and \u003Cbr\u003E2. Giving feedback.\u003Cbr\u003E\u003C\u002Ffont\u003E\r\n    \u003Cp\u003E\r\n\u003C\u002Fp\u003E\r\n  \u003C\u002Fsection\u003E\r\n  \u003Csection id=\"page2\" class=\"hidden\"\u003E\r\n    \u003Cp\u003E\u003Cfont size=\"6\"\u003EYou will see two items side by side on the screen. This time the code waits for a key response and then, based on RT, gives feedback.\u003Cbr\u003E\u003Cbr\u003EPress ENTER to check it out\u003C\u002Fp\u003E\u003C\u002Ffont\u003E\r\n  \u003C\u002Fsection\u003E\r\n\u003C\u002Fmain\u003E\r\n\r\n\u003Cfooter\u003E\r\n  \u003Ctable class=\"table-plain\"\u003E\r\n    \u003Ctr\u003E\r\n      \u003Ctd id=\"bck\" style=\"visibility: hidden\"\u003E\r\n        press the left arrow \u003Ckbd\u003E&larr;\u003C\u002Fkbd\u003E for the previous screen \r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd id=\"done\" style=\"visibility: hidden\"\u003E\r\n        press \u003Ckbd\u003EENTER\u003C\u002Fkbd\u003E to continue \r\n      \u003C\u002Ftd\u003E\r\n      \u003Ctd id=\"fwd\"\u003E\r\n        press the right arrow \u003Ckbd\u003E&rarr;\u003C\u002Fkbd\u003E for the next screen \r\n      \u003C\u002Ftd\u003E\r\n    \u003C\u002Ftr\u003E\r\n  \u003C\u002Ftable\u003E\r\n\u003C\u002Ffooter\u003E"
    },
    {
      "type": "lab.flow.Loop",
      "templateParameters": [
        {
          "image1": "rubberduck1.jpg",
          "image2": "pumpkin1.jpg",
          "correct_resp": "1"
        },
        {
          "image1": "pruner1.jpg",
          "image2": "glasses2.jpg",
          "correct_resp": "1"
        },
        {
          "image1": "tree2.jpg",
          "image2": "basket2.jpg",
          "correct_resp": "2"
        }
      ],
      "sample": {
        "mode": "draw-shuffle"
      },
      "files": {
        "rubberduck1.jpg": "embedded\u002Ffbd80973b97e7b8e6f6ca937131578511c75a5172781dc12ed7e27c3368f1056.jpg",
        "glasses2.jpg": "embedded\u002F96b604143d08ea594823412865f7500fa97232f12e71d0a6facf988cde80b2a0.JPG",
        "pumpkin1.jpg": "embedded\u002Ff9f249d7c024b7216630477b56e5ceceecddbfd99c61391477c5cd6126d6872f.jpg",
        "pruner1.jpg": "embedded\u002F7d4090aec58f4b367c1fe1662d4b4ca1102b2862712805773127ef643e8d3861.jpg",
        "tree2.jpg": "embedded\u002F3e111a01dbefd8e3c0fa46d6c125d903ba62e600fd83e02b9645300354537caa.jpg",
        "basket2.jpg": "embedded\u002F37fed9e5bff9a4f114662beb6d478e6fe8da1e6f8dbd8ac206bc5f6b0e0eaa5c.jpg"
      },
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "test_buffer_loop",
      "shuffleGroups": [],
      "template": {
        "type": "lab.flow.Sequence",
        "files": {},
        "responses": {},
        "parameters": {},
        "messageHandlers": {},
        "title": "test_buffer_sequence",
        "content": [
          {
            "type": "lab.canvas.Screen",
            "content": [],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {},
            "parameters": {},
            "messageHandlers": {},
            "title": "ISI",
            "timeout": "400"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "image",
                "left": 175,
                "top": -75,
                "angle": 0,
                "width": 238.08,
                "height": 238.08,
                "stroke": null,
                "strokeWidth": 0,
                "fill": "black",
                "src": "${ this.files[this.parameters.image2] }"
              },
              {
                "type": "image",
                "left": -175,
                "top": -75,
                "angle": 0,
                "width": 240.64,
                "height": 240.64,
                "stroke": null,
                "strokeWidth": 0,
                "fill": "black",
                "src": "${ this.files[this.parameters.image1] }"
              },
              {
                "type": "i-text",
                "left": -175,
                "top": 86,
                "angle": 0,
                "width": 13,
                "height": 20.34,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "N",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "18",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "i-text",
                "left": 175,
                "top": 85,
                "angle": 0,
                "width": 14.99,
                "height": 20.34,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "M",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "18",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              },
              {
                "type": "i-text",
                "left": 0,
                "top": 175,
                "angle": 0,
                "width": 329.96,
                "height": 15.82,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "choose the item most likely to have been seen earlier",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": "14",
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {
              "backpack1.jpg": "embedded\u002F7283233f216629f56ec26db54701d15738745a97b02b46ba00fe91a91ce8dc42.jpg"
            },
            "responses": {
              "keypress(n)": "1",
              "keypress(m)": "2"
            },
            "parameters": {},
            "messageHandlers": {},
            "title": "test_buffer_stimulus",
            "correctResponse": "${ [this.parameters.correct_resp] }"
          },
          {
            "type": "lab.canvas.Screen",
            "content": [
              {
                "type": "i-text",
                "left": 0,
                "top": 0,
                "angle": 0,
                "width": 133.39,
                "height": 36.16,
                "stroke": null,
                "strokeWidth": 1,
                "fill": "black",
                "text": "Too slow!",
                "fontStyle": "normal",
                "fontWeight": "normal",
                "fontSize": 32,
                "fontFamily": "sans-serif",
                "lineHeight": 1.16,
                "textAlign": "center"
              }
            ],
            "viewport": [
              800,
              600
            ],
            "files": {},
            "responses": {},
            "parameters": {},
            "messageHandlers": {},
            "title": "test_buffer_feedback",
            "timeout": "1000",
            "tardy": true,
            "skip": "${ this.state.duration \u003C 2000 }"
          }
        ]
      }
    },
    {
      "type": "lab.canvas.Screen",
      "content": [
        {
          "type": "i-text",
          "left": 0,
          "top": 0,
          "angle": 0,
          "width": 485.69,
          "height": 78.11,
          "stroke": null,
          "strokeWidth": 1,
          "fill": "black",
          "text": "end of demo\ndata available for download above",
          "fontStyle": "normal",
          "fontWeight": "normal",
          "fontSize": 32,
          "fontFamily": "sans-serif",
          "lineHeight": 1.16,
          "textAlign": "center"
        }
      ],
      "viewport": [
        800,
        600
      ],
      "files": {},
      "responses": {},
      "parameters": {},
      "messageHandlers": {},
      "title": "end",
      "timeout": "1500"
    }
  ]
})

// Let's go!
study.run()
